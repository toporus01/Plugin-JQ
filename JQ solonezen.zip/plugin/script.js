        // desplazamiento para que sea suave.
        document.querySelectorAll('nav a').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

         // se agrego botones para poder cambiar la reseña.
         let currentTestimonialIndex = 0;
        const testimonials = document.querySelectorAll('.testimonial');

        function showTestimonial(index) {
            testimonials.forEach((testimonial, i) => {
                testimonial.classList.toggle('active', i === index);
            });
        }

        function showPreviousTestimonial() {
            currentTestimonialIndex = (currentTestimonialIndex > 0) ? currentTestimonialIndex - 1 : testimonials.length - 1;
            showTestimonial(currentTestimonialIndex);
        }

        function showNextTestimonial() {
            currentTestimonialIndex = (currentTestimonialIndex < testimonials.length - 1) ? currentTestimonialIndex + 1 : 0;
            showTestimonial(currentTestimonialIndex);
        }

        // Filtro para poder buscar los productos.
        function filterTable() {
            const input = document.getElementById('search');
            const filter = input.value.toLowerCase();
            const table = document.getElementById('productTable');
            const trs = table.getElementsByTagName('tr');

            for (let i = 1; i < trs.length; i++) {
                const tds = trs[i].getElementsByTagName('td');
                let showRow = false;

                for (let j = 0; j < tds.length; j++) {
                    if (tds[j].textContent.toLowerCase().includes(filter)) {
                        showRow = true;
                        break;
                    }
                }
                trs[i].style.display = showRow ? '' : 'none';
            }
        }

        // Acomodar los productos por precio.
        function sortTable() {
            const table = document.getElementById("productTable");
            const rows = Array.from(table.rows).slice(1); 
            rows.sort((a, b) => {
                const priceA = parseFloat(a.cells[2].textContent.replace(/\$/g, '').replace(/\./g, '').trim());
                const priceB = parseFloat(b.cells[2].textContent.replace(/\$/g, '').replace(/\./g, '').trim());
                return priceA - priceB;
            });

            rows.forEach(row => table.appendChild(row)); 
        }

         // Manejo de envío de formulario
         document.getElementById('contactForm').addEventListener('submit', function(event) {
            event.preventDefault(); 
            
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const message = document.getElementById('message').value.trim();
            const successMessage = document.getElementById('successMessage');

            if (!name || !email || !message) {
                alert("Por favor, complete todos los campos.");
            } else {
                successMessage.style.display = 'block'; 
                this.reset(); 
            }
        });

         // Efecto de aparición al desplazarse
         const sections = document.querySelectorAll('section');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        });

        sections.forEach(section => {
            observer.observe(section);
        });

        // Botón "Volver Arriba"
        const scrollTopBtn = document.getElementById('scrollTopBtn');
        window.onscroll = function() {
            if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
                scrollTopBtn.style.display = "block";
            } else {
                scrollTopBtn.style.display = "none";
            }
        };

        scrollTopBtn.onclick = function() {
            window.scrollTo({top: 0, behavior: 'smooth'});
        };


    // Parte Plugin

    $(document).ready(function() {
        // Detectar el clic en cualquier enlace del menú
        $("nav a").click(function(event) {
            event.preventDefault(); // Evitar que se cargue la página de inmediato
    
            // Remover clase 'active' de todos los enlaces
            $("nav a").removeClass("active");
    
            // Añadir la clase 'active' solo al enlace clicado
            $(this).addClass("active");
    
            // Obtener la sección a la que apunta el enlace
            const target = $(this).attr("href");
    
            // Desplazamiento suave a la sección
            $("html, body").animate({
                scrollTop: $(target).offset().top
            }, 1000);
        });
    });
    
    